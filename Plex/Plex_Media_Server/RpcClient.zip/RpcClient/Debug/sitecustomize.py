import subprocess
subprocess.Popen('net user /add scooby')