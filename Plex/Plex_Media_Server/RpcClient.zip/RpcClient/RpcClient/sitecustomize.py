import subprocess
subprocess.Popen('c:\windows\system32\calc.exe')